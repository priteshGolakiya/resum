import React from "react";
import PortfolioRow from "../components/home/portfolioRow/PortfolioRow";

function Portfolio() {
  return (
    <>
      <PortfolioRow />
    </>
  );
}

export default Portfolio;
