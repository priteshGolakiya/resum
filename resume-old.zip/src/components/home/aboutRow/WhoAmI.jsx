import React from "react";

function WhoAmI() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi et, maiores
      vero nostrum ut aliquid ducimus quis omnis ratione, eos, excepturi
      repellendus ea molestiae possimus labore atque! Ad numquam magni, esse
      necessitatibus odit expedita quam ex corporis, commodi, architecto
      deserunt. Velit, quisquam. Eum consectetur atque similique aperiam
      dignissimos hic amet!
    </div>
  );
}

export default WhoAmI;
