import React from "react";

function Portfolio() {
  return <div>Portfolio</div>;
}

export default Portfolio;
